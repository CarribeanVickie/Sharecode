<?php
// display_items.php

// Connect to your database (replace with your actual database credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "debbiemotors";

$connection = new mysqli($servername, $username, $password, $dbname);

if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Fetch items from the 'items' table
$sql = "SELECT * FROM products";
$result = $connection->query($sql);

// Display items in a list
while ($row = $result->fetch_assoc()) {
    echo "<div class='uploaded-photo'>";
    echo "<img src='" . $row["PImg"] . "' alt='" . $row["PId"] . "' style='max-width: 100%;'>";
    echo "<p><strong>Name:</strong> " . $row["Pname"] . "</p>";
    echo "<p><strong>Product Type:</strong> " . $row["PType"] . "</p>";
    echo "</div>";
}


$connection->close();
?>