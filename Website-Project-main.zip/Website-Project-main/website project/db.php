<?php

$hostName ="localhost";
$dbUser = "root";
$dbPassword ="";
$dbName = "debbiemotors";
$connection = mysqli_connect($hostName, $dbUser, $dbPassword, $dbName);

?>