<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipient = $_POST['recipient'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Send email
    mail($recipient, $subject, $message);

    echo "Email sent successfully!";
}

?>
