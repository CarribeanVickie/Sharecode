<?php
/*
// Email account details
$hostname = '{imap.gmail.com:993/imap/ssl}INBOX';
$username = 'ichuguvictor@gmail.com';
$password = 'MRpaulKIKS2022';

// Connect to the IMAP server
$mailbox = imap_open($hostname, $username, $password) or die('Cannot connect to mailbox: ' . imap_last_error());

// Get the number of messages in the mailbox
$totalMessages = imap_num_msg($mailbox);

// Display emails
echo "<ul>";
for ($i = 1; $i <= $totalMessages; $i++) {
    $header = imap_headerinfo($mailbox, $i);
    echo "<li>";
    echo "From: " . $header->fromaddress . " | ";
    echo "Subject: " . $header->subject . " | ";
    echo "Date: " . $header->date;
    echo "</li>";
}
echo "</ul>";

// Close the mailbox
imap_close($mailbox);
*/
?>
 