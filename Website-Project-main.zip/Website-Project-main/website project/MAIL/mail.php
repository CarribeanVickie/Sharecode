<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Application</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        textarea {
            width: 100%;
            height: 100px;
        }
    </style>
</head>
<body>
    <h1>Email Application</h1>

    <form action="send_email.php" method="post">
        <label for="recipient">Recipient:</label>
        <input type="email" name="recipient" required>
        
        <label for="subject">Subject:</label>
        <input type="text" name="subject" required>
        
        <label for="message">Message:</label>
        <textarea name="message" required></textarea>
        
        <input type="submit" value="Send Email">
    </form>

    <hr>

    <h2>Inbox</h2>

    <?php include 'inbox.php'; ?>

</body>
</html>
